# TENAZ

Ishki hám sırtqı qapılar satatuǵın jańa dúkan.

- Baha: [[onimler-hem-bahalar]] betin qara
- Klientler: [[tenaz-misal-klient]]
- Logotip, reń hám slogan qayta kóriletuǵın bolıp atır — juwmaqlanbaǵan

Baylanıslı: [[mashqalalar]], [[maqsetler]]
