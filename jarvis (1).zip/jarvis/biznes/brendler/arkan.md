# ARKAN

Swarka sexi — temir qayta islew: ograjdeniye/reshotka, temir qapı-warota
islep shıǵarıw, hám kóshe swarshılarına xızmet kórsetiw.

- Baha: [[onimler-hem-bahalar]] betin qara
- Klientler: [[arkan-misal-klient]]
- Logotip reńi: tıqır kók (navy) + portokal, eki halqa belgi
- Slogan: **"Bekkemlik bizden baslanadı"**

Baylanıslı: [[mashqalalar]], [[maqsetler]]
