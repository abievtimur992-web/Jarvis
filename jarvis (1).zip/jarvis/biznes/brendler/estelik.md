# ESTELIK

Estelik tas hám temir qorshawlar islep shıǵarıw hám satıw.

- Baha: [[onimler-hem-bahalar]] betin qara
- Klientler: [[estelik-misal-klient]]
- Logotip reńi: qara fon, altın-sarı (mesjit/minara silueti)
- Slogan: belgisiz

Baylanıslı: [[mashqalalar]], [[maqsetler]]
