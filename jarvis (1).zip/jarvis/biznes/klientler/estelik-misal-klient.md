# Estelik-mısal-klient (úlgi jazba)

Bul — úlgi jazba. Naqtı klient atın jaz (yamasa oylap tabılǵan at qolla, mısalı
"Bekzat-aga"), bul jazbanı óshirip taslasań da boladı.

- Brend: [[ESTELIK]]
- Ne satıp aldı: granit estelik tas
- Baylanıs: (telefon nomerin osı jerge jaz)
- Eskertpe: klientler kóbinese jaqınınan ayrılǵan, 25–50 jastaǵı adamlar
  boladı — olarǵa jılı hám húrmet penen sóylesiw kerek.
