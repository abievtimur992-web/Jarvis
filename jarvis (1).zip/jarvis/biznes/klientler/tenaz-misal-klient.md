# Tenaz-mısal-klient (úlgi jazba)

Bul — úlgi jazba. Naqtı klient atın jaz.

- Brend: [[TENAZ]]
- Klient túri: úy salıp atırǵan adam yamasa qurılıs obyekti
- Buyırtpa: ishki yamasa sırtqı qapı
- Baylanıs: (telefon nomerin osı jerge jaz)
