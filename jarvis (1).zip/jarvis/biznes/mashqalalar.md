# Mashqalalar

Bul jerge biznesińde ushırasqan mashqalalardı jaz — Jarvis `brief_me` hám
`plan_day` ushın osını oqıydı.

## Finans
- Pul jetispewshiligi — aldıńǵı jıllardaǵı zıyannan qalǵan kreditler hám
  qarızlar. Kirim-shıǵın teńsiz.
- Kirim: [[ESTELIK]]-ten ~4 mln, [[ARKAN]]-nan ~6.5 mln som/ay.

## Marketing
- [[ARKAN]], [[ESTELIK]] hám [[TENAZ]] ushın SMM/target jarnama joq.
- Instagram ele islep baslanbaǵan.

## Búgingi jazba mısalı
- 11-sentyabr: [[TENAZ]] dúkanı ushın jańa qapı úlgileri keldi (mısal jazba —
  ózgert yamasa óshir).

Baylanıslı: [[onimler-hem-bahalar]], [[maqsetler]]
