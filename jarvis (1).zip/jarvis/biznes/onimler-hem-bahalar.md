# Ónimler hám bahalar

Bul úlgi jazba — hár bir brendtiń ónimlerin hám bahaların osı jerge jaz.
Bahalar ózgerse, sáneni jańalap, eski bahanı "(eski)" dep belgile.

## [[ESTELIK]]
- Granit estelik tas — 500 000 – 600 000 som
- Temir ograjdeniye (10 metr) — 1 500 000 – 6 000 000 som

## [[ARKAN]]
- Ograjdeniye/reshotka, temir qapı-warota — baha ónim boyınsha
- Jańa produkt tayarlanıp atır — bahası **belgisiz**, tayar bolǵanda osı
  jerge jaz

## [[TENAZ]]
- Ishki hám sırtqı qapılar — 1 000 000 – 5 000 000 som

Baylanıslı: [[mashqalalar]], [[maqsetler]]
